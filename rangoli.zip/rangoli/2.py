hw = list(map(int, input().split()))
v = '.|.'
m_ln = hw[-1]
l = ''
li = []
for i in range(1, m_ln, 2):
    if len(l) < m_ln-6:
        l = v*i
        print(l.center(m_ln, '-'))
        li.append(l)
    else:
        print('WELCOME'.center(m_ln, '-'))
        break 
for i in li[::-1]:
    print(i.center(m_ln, '-'))