import math


h = "H"
l = int(input())
li1 = []
for i in range(1,l*2, 2):
    v = str(i*h).center((l*2)-1, ' ')
    print(v)
    li1.append(v)

li2 = []
for i in range(1,l*2, 2):
    v2 = str(l*h).center((l*2)-1, ' ') + (' '*(l*2)) +str(l*h).center((l*2)-1, ' ')
    print(v2)
    li2.append(v2)

# middle ======
for i in range((l//2)+1):
    m = l//2
    n = l*l
    print(str(n*h).center(6*l-1," "))

for i in range(1,l*2, 2):
    v2 = str(l*h).center((l*2)-1, ' ') + (' '*(l*2)) +str(l*h).center((l*2)-1, ' ')
    print(v2)
    li2.append(v2)
    
li1_rev = li1[::-1]
for i in li1_rev:
    n = l*l
    p = len(li2[0])
    # print(p,"=======p")
    print(str(i).rjust(p,' '))