size = int(input())
alph_li = [chr(i) for i in range(97,97+size)][::-1]

len_li = (size*size)
st = len_li*'-'
ind = 0
li = []
for f in alph_li:
    ind+=1
    sl_val = alph_li[:ind]
    st1 = '-'.join(list(alph_li[:ind]))
    if len(sl_val) > 1:
        ind1 = ind-1
        rev_lisli = sl_val[:ind1][::-1]
        st1 = str('-'.join(sl_val)+'-'+'-'.join(rev_lisli))
        
    li.append(st1)
li8 = li[::-1]
len_last = len(li[-1])
for i in li:
    print(str(i).center(len_last,'-'))
for i in range(1, len(li8)):
    print(str(li8[i]).center(len_last,'-'))
